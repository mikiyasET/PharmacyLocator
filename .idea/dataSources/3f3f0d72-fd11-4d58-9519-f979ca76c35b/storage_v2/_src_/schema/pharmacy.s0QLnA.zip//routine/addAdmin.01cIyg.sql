create
    definer = root@localhost procedure addAdmin(IN id varchar(13), IN user varchar(50), IN pass text) no sql
insert into admin (aid,username,password) VALUES(id,user,pass);

